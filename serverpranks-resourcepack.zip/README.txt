To use your own sounds, replace these files (keep the names, .ogg format):
  assets/serverpranks/sounds/usb_disconnect.ogg
  assets/serverpranks/sounds/usb_connect.ogg
  assets/serverpranks/sounds/jumpscare.ogg
Current ones are simple placeholder sounds.
The jumpscare picture is assets/minecraft/textures/misc/pumpkinblur.png
(shown full-screen whenever a carved pumpkin is worn).
